#!/bin/sh

#  killDeamonAndMonitor.sh
#  Lemon
#
#  Created by klkgogo on 2018/10/31.
#  Copyright © 2018 Tencent. All rights reserved.
launchctl unload /Library/LaunchDaemons/com.tencent.Lemon.plist
launchctl unload /Library/LaunchAgents/com.tencent.LemonMonitor.plist
pkill -f LemonMonitor
pkill -f LemonDaemon
