#!/bin/sh

#  createRemoveFlagFile.sh
#  Lemon
#
#  Created by klkgogo on 2018/11/6.
#  Copyright © 2018 Tencent. All rights reserved.
mkdir /Library/Application\ Support/Lemon
touch /Library/Application\ Support/Lemon/movedFlag
chmod +r /Library/Application\ Support/Lemon/movedFlag
