#! /bin/sh
launchctl unload /Library/LaunchDaemons/com.aaa.windscribe.OVPNHelper.plist
rm /Library/LaunchDaemons/com.aaa.windscribe.OVPNHelper.plist
rm /Library/PrivilegedHelperTools/com.aaa.windscribe.OVPNHelper