//
//  AppDelegate.h
//  dlnaDemo
//
//  Created by MccRee on 2018/5/4.
//  Copyright © 2018年 mccree. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

