//
//  dlnaTestVC.h
//  YSTThirdSDK_Example
//
//  Created by MccRee on 2018/2/9.
//  Copyright © 2018年 MQL9011. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DLNASearchVC : UIViewController

@end
