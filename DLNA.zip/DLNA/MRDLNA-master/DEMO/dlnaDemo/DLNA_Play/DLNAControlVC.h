//
//  DLNAControlVC.h
//  YSTThirdSDK_Example
//
//  Created by MccRee on 2018/2/11.
//  Copyright © 2018年 MQL9011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MRDLNA/MRDLNA.h>

@interface DLNAControlVC : UIViewController

@property (nonatomic, strong) CLUPnPDevice *model;

@end
