//
//  MRAppDelegate.h
//  MRDLNA
//
//  Created by MQL9011 on 05/04/2018.
//  Copyright (c) 2018 MQL9011. All rights reserved.
//

@import UIKit;

@interface MRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
