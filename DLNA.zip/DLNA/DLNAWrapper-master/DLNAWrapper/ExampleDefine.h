//
//  ExampleDefine.h
//  DLNAWrapper
//
//  Created by Key.Yao on 16/9/28.
//  Copyright © 2016年 Key. All rights reserved.
//

#ifndef ExampleDefine_h
#define ExampleDefine_h

#define THEME_COLOR [UIColor colorWithFormat:@"#3f51b5"]


#endif /* ExampleDefine_h */
