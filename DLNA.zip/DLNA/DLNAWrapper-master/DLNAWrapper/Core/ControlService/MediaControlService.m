//
//  MediaControlService.m
//  DLNAWrapper
//
//  Created by Key.Yao on 16/9/19.
//  Copyright © 2016年 Key. All rights reserved.
//

#import "MediaControlService.h"

@implementation MediaControlService

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.name = @"MediaControl";
    }
    return self;
}

@end
