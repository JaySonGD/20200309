//
//  RenderingControlService.m
//  DLNAWrapper
//
//  Created by Key.Yao on 16/9/19.
//  Copyright © 2016年 Key. All rights reserved.
//

#import "RenderingControlService.h"

@implementation RenderingControlService

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.name = @"RenderingControl";
    }
    return self;
}

@end
