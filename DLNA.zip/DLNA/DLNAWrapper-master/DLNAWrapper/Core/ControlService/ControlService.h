//
//  ControlService.h
//  DLNAWrapper
//
//  Created by Key.Yao on 16/9/19.
//  Copyright © 2016年 Key. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ControlService : NSObject

@property NSString *name;
@property NSString *type;
@property NSString *controlURL;
@property NSString *eventSubURL;

@end
