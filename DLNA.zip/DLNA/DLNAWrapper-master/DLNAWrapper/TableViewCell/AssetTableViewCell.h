//
//  AssetTableViewCell.h
//  DLNAWrapper
//
//  Created by Key.Yao on 16/9/28.
//  Copyright © 2016年 Key. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssetTableViewCell : UITableViewCell

@property UIImageView *iconView;

@property UILabel *titleLabel;

@end
