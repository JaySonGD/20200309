//
//  ViewController.h
//  DLNAWrapper
//
//  Created by Key.Yao on 16/9/19.
//  Copyright © 2016年 Key. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DeviceChangeDelegate.h"

@interface MainViewController : UIViewController <DeviceChangeDelegate>


@end

