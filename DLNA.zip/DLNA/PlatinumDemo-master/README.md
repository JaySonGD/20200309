#PlatinumDemo
DEMO使用platinum库完成了小部分DLNA功能，包括播放，暂停，上一首，下一首，调音量等，首发地址：[简书](http://www.jianshu.com/p/0b8df8988a7f)
