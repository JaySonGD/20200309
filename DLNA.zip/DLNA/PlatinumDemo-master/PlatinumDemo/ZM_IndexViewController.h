//
//  ZM_IndexViewController.h
//  PlatinumDemo
//
//  Created by GVS on 16/11/24.
//  Copyright © 2016年 GVS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZM_IndexViewController : UIViewController

@end
