//
//  AppDelegate.h
//  PlatinumDemo
//
//  Created by GVS on 16/11/22.
//  Copyright © 2016年 GVS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

