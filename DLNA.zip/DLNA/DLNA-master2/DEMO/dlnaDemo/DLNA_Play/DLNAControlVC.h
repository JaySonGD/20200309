//
//  DLNAControlVC.h
//  YSTThirdSDK_Example
//
//  Created by LW on 2018/2/11.
//  Copyright © 2018年 LW. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MRDLNA/MRDLNA.h>

@interface DLNAControlVC : UIViewController

@property (nonatomic, strong) CLUPnPDevice *model;

@end
