//
//  LocalShowPicVC.h
//  DLNA_Demo
//


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LocalShowPicVC : UIViewController
@property (nonatomic,strong)NSArray  *assetsArr;
@property (nonatomic,assign)NSInteger  currentIndex;
@end

NS_ASSUME_NONNULL_END
