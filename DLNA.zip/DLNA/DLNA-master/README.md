# DLNA
本Demo是实现网络/本地视频图片的投屏，包括一些常见的控制指令，快进退，上下集切换，音量等等（在悦me盒子上已经实践）

可详见
简书
- [DLNA（一）](https://www.jianshu.com/p/afecbcf2c496)
- [DLNA（二）](https://www.jianshu.com/p/d0dd4d0246dc)
- [DLNA（三）](https://www.jianshu.com/p/ef258694b589)
