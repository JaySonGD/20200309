<?php
/**
 * Created by PhpStorm.
 * User: mickey
 * Date: 2018/7/28
 * Time: 13:55
 */

return [
    'http_proxy' => '',
    'weiboCookie' => 'SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WW3PsCb55p3CXxHR9oDv0OW5JpX5KzhUgL.FozN1KefehzXS052dJLoIEXLxKBLB.BLBK5LxKnL1hBLBo2LxKnLBoBLB-zLxKBLB.2L1hqLxK-L1K5L1KMt;  SUB=_2A25xqLwdDeRhGeRJ4lEU8CzIzDyIHXVS36rVrDV8PUNbn9BeLWTXkW9NUklEG2ghQmTSYlBq7Ojj_RI2o5TCBO6W;'
];