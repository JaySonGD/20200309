<?php
/**
 * Created by PhpStorm.
 * User: mickey
 * Date: 2018/7/10
 * Time: 14:16
 */
namespace core\Style;

class Color
{
    public $color='';

    public function make()
    {

    }

    public function defaultColor()
    {

    }

}