<?php
/**
 * Created by PhpStorm.
 * User: mickey
 * Date: 2019-03-07
 * Time: 16:09
 */

namespace core\Common;


class Uuid
{
    public $ns = '';

    /**
     * UUID version 5
     * @return string
     */
    public static function uuidv5():string
    {
        return '';
    }
}