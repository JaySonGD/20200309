<?php
/**
 * Created by PhpStorm.
 * User: mickey
 * Date: 2018/7/18
 * Time: 20:37
 */

namespace core\Common;


class File
{
    public static function touch()
    {

    }
}