//
//  NSObject+UIStatusBarTimeItemView.m
//  YHWanGuoTechnicians
//
//  Created by Jay on 19/9/18.
//  Copyright © 2018年 Zhu Wensheng. All rights reserved.
//

#import "NSObject+UIStatusBarTimeItemView.h"

@implementation NSObject (UIStatusBarTimeItemView)

- (id)valueForUndefinedKey:(NSString *)key{
    return nil;
}

@end
