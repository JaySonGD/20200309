//
//  NSObject+UIStatusBarTimeItemView.h
//  YHWanGuoTechnicians
//
//  Created by Jay on 19/9/18.
//  Copyright © 2018年 Zhu Wensheng. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (UIStatusBarTimeItemView)

@end

NS_ASSUME_NONNULL_END
