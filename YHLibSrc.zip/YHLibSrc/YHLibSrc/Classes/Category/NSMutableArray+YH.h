//
//  NSMutableArray+YH.h
//  
//
//  Created by Zhu Wensheng on 2017/8/24.
//
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (YH)

- (void)moveObjectFromIndex:(NSUInteger)fromIndex toIndex:(NSUInteger)toIndex;
@end
