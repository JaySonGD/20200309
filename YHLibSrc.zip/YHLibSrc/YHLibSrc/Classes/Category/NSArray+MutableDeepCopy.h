//
//  NSArray+MutableDeepCopy.h
//  YHWanGuoTechnicians
//
//  Created by Zhu Wensheng on 2018/5/9.
//  Copyright © 2018年 Zhu Wensheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (MutableDeepCopy)

-(NSMutableArray *)mutableDeepCopy;
//增加mutableDeepCopy方法
@end
