//
//  NSDictionary+MutableDeepCopy.h
//  YHWanGuoTechnicians
//
//  Created by Zhu Wensheng on 2017/5/29.
//  Copyright © 2017年 Zhu Wensheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (MutableDeepCopy)

-(NSMutableDictionary *)mutableDeepCopy;
//增加mutableDeepCopy方法
@end
