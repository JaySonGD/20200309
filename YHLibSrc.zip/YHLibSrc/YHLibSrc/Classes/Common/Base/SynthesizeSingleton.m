//
//  SynthesizeSingleton.m
//  SingleObj
//
//  Created by Zhu wensheng on 13-7-10.
//
//

#import "SynthesizeSingleton.h"

