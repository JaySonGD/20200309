//
//  YHViewController.m
//  YHLibSrc

//  Created by czljcb@163.com on 10/16/2018.
//  Copyright (c) 2018 czljcb@163.com. All rights reserved.


#import "YHViewController.h"
#import <YHLibSrc/SynthesizeSingleton.h>
#import <YHLibSrc/ZZAlertViewController.h>

@interface YHViewController ()

@end

@implementation YHViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
