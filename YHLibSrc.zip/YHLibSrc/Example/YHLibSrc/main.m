//
//  main.m
//  YHLibSrc
//
//  Created by czljcb@163.com on 10/16/2018.
//  Copyright (c) 2018 czljcb@163.com. All rights reserved.
//

@import UIKit;
#import "YHAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([YHAppDelegate class]));
    }
}
