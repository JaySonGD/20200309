# YHLibSrc

[![CI Status](https://img.shields.io/travis/czljcb@163.com/YHLibSrc.svg?style=flat)](https://travis-ci.org/czljcb@163.com/YHLibSrc)
[![Version](https://img.shields.io/cocoapods/v/YHLibSrc.svg?style=flat)](https://cocoapods.org/pods/YHLibSrc)
[![License](https://img.shields.io/cocoapods/l/YHLibSrc.svg?style=flat)](https://cocoapods.org/pods/YHLibSrc)
[![Platform](https://img.shields.io/cocoapods/p/YHLibSrc.svg?style=flat)](https://cocoapods.org/pods/YHLibSrc)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

YHLibSrc is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:


```ruby
project 'XXXXX.xcodeproj'

source 'https://github.com/CocoaPods/Specs.git'  #官方仓库的地址
source 'http://git.mhace.com/ios/YHLibSpec.git'

target 'XXXXX' do

pod 'YHLibSrc'

end
```

## Author

czljcb@163.com, caozhi@mhace.com

## License

YHLibSrc is available under the MIT license. See the LICENSE file for more info.
